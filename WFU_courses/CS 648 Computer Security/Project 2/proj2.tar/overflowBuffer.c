
/* overflowBuffer.c   CSC348/648  2/28/2013                      */  
/* This program will jump to the shell code by copying the       */  
/* contents of largeString into the variable buffer              */  
/*                                                               */  

#include<stdio.h>  
#include<string.h>  
#include"amdshellcode.h"  

/* change the next line to appropriate buffer size               */  
#define BUFFER_SIZE 8  

char largeString[BUFFER_SIZE];  

void function()
{
	char buffer[96];  

	/* Initialize buffer with 0x90 (NOP instruction)              */
	memset(&largeString, 0x90, BUFFER_SIZE);

	/* You need to fill largeString with appropriate contents     */
	/* have fun...                                                */  

	strcpy(buffer, largeString);  

}

int main()
{
	function();  
	return 0;  
}  


