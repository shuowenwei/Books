
/* jumpShell.c   CSC348/648  2/28/2013                           */  
/* This program will jump to the shell code                      */  
/*                                                               */  

#include<stdio.h>  
#include"amdshellcode.h"  

int main();  

void function(int a, int b, int c)  
{
	char buffer[5];
	long* ret;

	/* set ret to the return address on the stack and change the  */  
	/* value to jump to shellcode                                 */  

}  

int main()
{
	int x = 0; 
	function(1, 2, 3);
	x = 1;
	printf("x = %i \n", x);   
	return 0;  
}  


