
/* skipLine.c   CSC348/648  2/18/2013                            */  
/* Add a few lines to skip the "x = 1;" line in main             */  
/* skipping must be done by altering the stack...                */  
/*                                                               */  

#include<stdio.h>  

int main();  

void function(int a, int b, int c)  
{
	char buffer[5];
	long* ret;

	/* set ret to the return address on the stack and change the  */  
	/* value to skip over "x = 1;"                                */  

}  

int main()
{
	int x = 0; 
	function(1, 2, 3);
	x = 1;
	printf("x = %i \n", x);  
	return 0;  
}  


