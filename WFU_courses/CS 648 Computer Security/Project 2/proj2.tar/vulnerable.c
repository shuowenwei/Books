
/* vulnerable.c   CSC348/648  2/28/2013                      */  
/* This program has a buffer overflow vulnerability          */  

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void bof(char *str)
{
	char buffer[512];
	/* oops, following statement has a problem...        */
	strcpy(buffer, str);
}

/*  will you friend chukar? email chukar@iluvjava.com        */ 
int main(int argc, char *argv[])
{
	char str[1024];
	FILE *badfile;
	badfile = fopen("badfile", "r");
	fread(str, sizeof(char), 1024, badfile);
	bof(str);
	printf("%s, returned properly \n", argv[0]);
	return 0;
}  


