<?php
// All code was wrote by Tim Kipp @ TimKippTutorials.com - December 20, 2011

// This code will allow you to remove all the file and subdirectories within the specified directory
// and then remove the directory that was passed in the function

function removeFolder($folder) {
	// check to see if the path passed into the function is a real directory
	if (is_dir($folder) === true) {
		// get all the files of the folder and put them into an array
		$folderContents = scandir($folder);
		// remove the first to items in the folder array ( '.' , '..' )
		unset($folderContents[0], $folderContents[1]);
		// loop through all of the items in the folder array
		foreach ($folderContents as $content => $contentName) {
			// set the current path of the current array item
			$currentPath = $folder.'/'.$contentName;
			// store the filetype of the current array item
			$filetype = filetype($currentPath);
			// determine if the current filetype is a directory or file
			if ($filetype == 'dir') { // is directory
				// run the current subdirectory path through the same function
				removeFolder($currentPath);
			} else { // is file
				// delete the file
				unlink($currentPath);
			}
			// remove the current array item from the array
			unset($folderContents[$content]);
		}
		// remove current folder that is passed into the function
		rmdir($folder);
	}
}

// call function to remove folder
removeFolder('CHANGE TO YOUR FOLDER PATH');
?>