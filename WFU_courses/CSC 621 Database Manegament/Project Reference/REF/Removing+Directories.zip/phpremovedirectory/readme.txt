THANK YOU FOR DOWNLOADING THE SOURCE CODE FOR REMOVING DIRECTORY FILES AND SUBDIRECTORIES FROM THE TIMKIPPTUTORIALS.COM CODE BANK.

Make sure you set your correct path when you call the function.

IF YOU HAVE QUESTIONS, FEEL FREE TO CONTACT ME IN THE FORUMS AT http://www.timkipptutorials.com/forums

THANK YOU AGAIN.

http://www.timkipptutorials.com