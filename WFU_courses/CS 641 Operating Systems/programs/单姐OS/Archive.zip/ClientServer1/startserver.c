#include <sys/types.h>
#include <sys/msg.h>
#include <unistd.h>
#include <iostream>
#include <stdio.h>
#include <sys/errno.h>
#include <sys/wait.h>
#include <limits.h>
#include <fstream>
#include <signal.h>
#include <string>

using namespace std ;

enum{READ,WRITE};
const int MAX=400;
const int ARGMAX=10;

void execute_new(char InputLine[MAX],char buffer1[PIPE_BUF],int ErrorFlag[1]);
void signal_catcher(int);

int main(int argc, char *argv[])
{
    int gflags,sflags,rflags;
    key_t key;
    int msgid;
    int reval;
    int n;
    int ErrorFlag[1];

    char buffer[PIPE_BUF];
    char buffer1[PIPE_BUF];
    struct sigaction new_action;

    //signal part:
    new_action.sa_handler = signal_catcher;
    new_action.sa_flags = 0;
    sigaction(SIGUSR1,&new_action,NULL);


    key=ftok(".",'f');
    gflags=IPC_CREAT|IPC_EXCL;
    msgid=msgget(key,gflags|0660); //00666 OK  0660 OK
    if(msgid==-1){ printf("msg create error\n"); return 1 ;}



    struct msgsbuf{
        long mtype;
        long MessageFrom;
	long ErrorFlag;
        char mtext[4096];
        }msg_sbuf_1,msg_rbuf;

    struct msqid_ds msg_ginfo , msg_sinfo;

    FILE *fin;
    fin =popen("ipcs -q","r");
    while((n=read(fileno(fin),buffer,PIPE_BUF))>0)      write(fileno(stdout),buffer,n) ;
    pclose(fin);

    int pid;
    pid =fork();
    //ErrorFlag[0]=0;
    switch(pid){
        case 0 :
 
            while(1){ 
            rflags =0;
	    ErrorFlag[0]=0;
            cout<<"Sever waiting"<<endl;
            reval = msgrcv(msgid,&msg_rbuf,sizeof(msg_rbuf.mtext),1,0);

            //reval=2;
            if(reval ==-1){
                //printf("msg receive error\n");
                }
            else{
                char InputLine[MAX];
                cout<<"Receive message from client"<<endl;
                strcpy(InputLine,msg_rbuf.mtext);
		
		for(int i=0;i<4096;i++) {buffer1[i]=' ';} //empty previous result
	
                execute_new(InputLine,buffer1,ErrorFlag);
		cout<<"ErrorFlag " <<ErrorFlag[0]<<endl;
                }


            //Send back
	   
            cout<<msg_rbuf.MessageFrom<<endl;
            msg_sbuf_1.mtype=msg_rbuf.MessageFrom;
            msg_sbuf_1.MessageFrom = (long) getpid() ;
	    msg_sbuf_1.ErrorFlag=0;
	    cout<<"ErrorFlag " <<ErrorFlag[0]<<endl;
	    if(ErrorFlag[0]==1) {cout<<"ErrorFlag " <<ErrorFlag[0]<<endl; msg_sbuf_1.ErrorFlag=(long) 1;}
	
            strcpy(msg_sbuf_1.mtext,buffer1);
            sflags=IPC_NOWAIT;
            if(reval !=-1 ){
                reval = msgsnd(msgid, &msg_sbuf_1,sizeof(msg_sbuf_1.mtext),sflags);
                if(reval==-1) {printf("message send error\n"); cout<<errno<<endl;}
                }
            } //End of loop , only signal would terminate this loop
            exit(1);

        default:
	    cout<<"Server PID number "<<pid<<endl;
            break;
        }

    return 1 ;
}


void execute_new(char InputLine[MAX],char buffer1[PIPE_BUF],int ErrorFlag[1])
{
     char *cmd_arg[ARGMAX];

     int i,j;
         for( i=0;i<ARGMAX;i++)       cmd_arg[i]=NULL;
     int CmdLen=strlen(InputLine);
     i=0;
     j=0;
     int tag=0;
     while(i<CmdLen && j<ARGMAX){
                      if(InputLine[i]==' '){
                              InputLine[i]='\0'; //as an end of one entry
                              tag=0;

                      }else if(InputLine[i]=='&'){
                    cout<<"Found &!"<<endl;
                InputLine[i]='\0'; //deal with ls& strip out "&"
                tag=2;             // flag to the function
              }
              else{
                              if(tag==0){
                      cmd_arg[j]=InputLine+i;
                      j++;
                      tag=1;
                                      }
                      }

                      i++;
              }


     int f_des_1[2];
     pipe(f_des_1);

     int pid,cpid ;
     pid=fork();


         switch(pid){
                  case 0: //---------child 
                  dup2(f_des_1[WRITE],fileno(stdout));
                  close(f_des_1[READ]);
                  close(f_des_1[WRITE]);
                  if(execvp(cmd_arg[0],&cmd_arg[0])<0)
                  {
                    switch(errno){

                    case ENOENT:
                        cout<<"&#Error! Command or file not found\n"<<endl;
                        break;
                    default :
                        cout<<"Error!"<<endl;
                        break;
                  }
                  }
                              exit(3);

                 default : //-------- parent
                 int cpid = waitpid(pid, NULL,0);
                 read(f_des_1[READ],buffer1,PIPE_BUF);
		 //if(strcmp(buffer1[0],'&')) cout<<"Error!"<<endl;
		if(buffer1[0]=='&' && buffer1[1]=='#')  
			{
				cout<<"Error!"<<endl;
				ErrorFlag[0]=1;
				cout<<ErrorFlag[0]<<endl;
			}
		 //cout<<buffer1[0]<<endl;
		 //cout<<buffer1[1]<<endl;
                 close(f_des_1[READ]);
                 close(f_des_1[WRITE]);

                }

}


void signal_catcher(int n){
    cout<<"Received SIGUSR1"<<endl;
    cout<<"Server Killed "<<endl;
    cout<<"Messagequeue Killed "<<endl;
    int msgid;
    int reval;
    key_t key;
    struct msgsbuf{
        long mtype;
        long MessageFrom;
	long ErrorFlag;
        char mtext[4096];
        }msg_sbuf_1,msg_sbuf_2 ,msg_rbuf;

    struct msqid_ds msg_ginfo , msg_sinfo;
    key=ftok(".",'f');
    msgid = msgget(key,IPC_CREAT);
    reval = msgctl(msgid,IPC_RMID,&msg_sinfo);

    exit(1);
}