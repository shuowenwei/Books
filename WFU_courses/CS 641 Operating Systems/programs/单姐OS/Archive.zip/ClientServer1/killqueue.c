#define _GNU_SOURCE
#include <cstdio>
#include <cstring>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <cstdio>
#include <iostream>
#include <sys/errno.h>

using namespace std ;




int main(int argc,char **argv)
{
	int gflags,sflags,rflags;
	key_t key;
	int msgid;
	int reval;
	char buffer[PIPE_BUF];
	int n;
	
	struct msgsbuf{
		long mtype;
		long MessageFrom;
		char mtext[200];
		}msg_sbuf_1,msg_sbuf_2 ,msg_rbuf;
	
	
		
	struct msqid_ds msg_ginfo , msg_sinfo;
	
	
	
	
	key=ftok(".",'f');
	msgid = msgget(key,IPC_CREAT);
	reval = msgctl(msgid,IPC_RMID,&msg_sinfo);
	
	//cout<<argv[0]<<endl;
	//cout<<argv[1]<<endl;
	FILE *fin;
	fin =popen("ipcs -q","r");
	while((n=read(fileno(fin),buffer,PIPE_BUF))>0)		write(fileno(stdout),buffer,n) ;
	pclose(fin);
	
	
	return 1 ;
		
    return 0;
} 
