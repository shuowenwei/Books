#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <sys/errno.h>
       
       
using namespace std ;
extern int errno;
      
const int MAX =200;
const int ARGMAX=10;
      
void execute_new(char *argv[],int tag);
void do_cd(char *argv[]);

int main(int argc,char *argv[])
{       
         char InputLine[MAX];
         char *cmd_arg[ARGMAX];
              
              
   
       
	cout<<"====Mini Shell===="<<endl;
	
	
	do{
	cout<<"Command>";
	cin.getline(InputLine,MAX,'\n');
              
              
	int i,j;
        for( i=0;i<ARGMAX;i++)       cmd_arg[i]=NULL;
        
	int CmdLen=strlen(InputLine);
              
	i=0;
	j=0;
	int tag=0;
	
	
	while(i<CmdLen && j<ARGMAX){
                      if(InputLine[i]==' '){
                              InputLine[i]='\0'; //as an end of one entry
                              tag=0;
			      
                      }else if(InputLine[i]=='&'){		      
		      		cout<<"Found &!"<<endl;
				InputLine[i]='\0'; //deal with ls& strip out "&"
				tag=2;             // flag to the function
		      }  
		      else{
                              if(tag==0){
				      cmd_arg[j]=InputLine+i;
				      j++;
				      tag=1;
                                      }
                      }
		      
                      i++;
              }
 	
	if(strcmp(cmd_arg[0],"quit")==0)
		{
			cout<<"====Bye Bye===="<<endl;
			break;
		}
		
	if(strcmp(cmd_arg[0],"cd")==0)
		{
			do_cd(cmd_arg);	
			continue;
		}
	
	
	execute_new(cmd_arg,tag);
	}while(1);

	return 1;
	
	}
	
	
void do_cd(char *argv[])
{
	chdir(argv[1]);
}
		
void execute_new(char *argv[],int tag)
{
	      int pid,cpid ;
              char *new_argv[]={"ls","-l",NULL};
                  pid=fork();
                  switch(pid){
                      case 0:
                              //execvp("/bin/ls",new_argv);
			      //sleep(1);
                              if(execvp(argv[0],&argv[0])<0)
			      {
			      	  cout<<argv[0]<<endl;
			      	  switch(errno){
				
				  	case ENOENT:
						cout<<"Error! Command or file not found "<<endl;
						break;
					default :
						cout<<"Error!"<<endl;
						break;
				  }
			      }
			      
                              exit(3);
			      
                     default :
		      	    if(tag == 2) {
			    	cout<<"Running Background !"<<endl;
			    	break;
                           	}
			    else{
			    	 cpid=waitpid(pid,NULL,0);	
		           	 break;
			    }
			      
      
                      }
// 		     
}	
	

