#include <sys/types.h>
#include <sys/msg.h>
#include <unistd.h>
#include <iostream>
#include <stdio.h>
#include <sys/errno.h>
#include <string.h>
#include <cstring>
#include <sys/wait.h>

using namespace std ;
extern int errno;
const int MAX=200;

int main(int argc, char *argv[])
{
	int gflags,sflags,rflags;
	key_t key;
	int msgid;
	int reval;
	
	char buffer[PIPE_BUF];
	int n;    
	
	char InputLine[MAX];
	
	
	struct msgsbuf{
		long mtype;
		long MessageFrom;
		long ErrorFlag;
		char mtext[4096];
		}msg_sbuf_1,msg_sbuf_2 ,msg_rbuf;
		
	struct msqid_ds msg_ginfo , msg_sinfo;
	
	//If the queue already exsits (created by the server), only returns the msggid number
	key=ftok(".",'f');
	msgid = msgget(key,IPC_CREAT);
	
	cout<<"---Mini Client---"<<endl;
	do{
	
	cout<<"ClientCommand> ";
	cin.getline(InputLine,MAX,'\n');

	if(strcmp(InputLine,"quit")==0) break;
	
			long PidNumber;
			PidNumber = (long) getpid(); 
			sflags=IPC_NOWAIT;
			
			msg_sbuf_1.mtype=  1 ;
			msg_sbuf_1.MessageFrom =PidNumber ;
			msg_sbuf_1.ErrorFlag=0;
			
			sprintf(buffer,"Message From %d",PidNumber);
			
			
			strcpy(msg_sbuf_1.mtext, InputLine);	
			reval = msgsnd(msgid, &msg_sbuf_1,sizeof(msg_sbuf_1.mtext),sflags);
	  		if(reval==-1) {printf("message send error\n");}
			//cout<<"I("<<PidNumber<<" )sent the message "<<endl;
		
			//receive back
			//Receive Back message
			rflags =0; //NEEDS THIS!
			msg_rbuf.ErrorFlag=0;
			
			
			reval = msgrcv(msgid,&msg_rbuf,sizeof(msg_rbuf.mtext), PidNumber,rflags);
			if(reval ==-1){
				cout<<reval<<endl;
				cout<<errno<<endl;
				printf("msg receive error\n");
				exit(1);}
			
			cout<<msg_rbuf.ErrorFlag<<endl;
			
			if(msg_rbuf.ErrorFlag!=1 ){
				cout<<msg_rbuf.mtext<<endl;
				}
			
			if(msg_rbuf.ErrorFlag==1) exit(1);
		
	
	}while(1);
		
	//FILE *fin;
	//fin =popen("ipcs -q","r");
	//while((n=read(fileno(fin),buffer,PIPE_BUF))>0)		write(fileno(stdout),buffer,n) ;
	//pclose(fin);
	
	
	
	return 1 ;
}
