//
//  main.m
//  Quiz
//
//  Created by Daniel Canas on 9/20/12.
//  Copyright (c) 2012 cs.wfu.wdu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "QuizAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([QuizAppDelegate class]));
    }
}
