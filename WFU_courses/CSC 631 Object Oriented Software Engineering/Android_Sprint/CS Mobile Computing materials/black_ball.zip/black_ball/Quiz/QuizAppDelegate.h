#import <UIKit/UIKit.h>

@interface QuizAppDelegate : NSObject <UIApplicationDelegate>
{
    int currentQuestionIndex;
    
    // The model objects
  NSMutableArray *questions;
    
    // The view objects - don't worry about the IBOutlet macro,
    // we'll talk about it shortly
//    IBOutlet UILabel *questionField;
    IBOutlet UILabel *answerField;
    IBOutlet UIImageView *imageView;
    
}

@property (nonatomic, retain) IBOutlet UIImageView *imageView;


- (IBAction)showImage:(id)sender;

@end
