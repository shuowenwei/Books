#import "QuizAppDelegate.h"


@implementation QuizAppDelegate

@synthesize window=_window;
@synthesize imageView = _imageview;

- (id)init
{
    // Call the init method implemented by the superclass
    self = [super init];
    if (self) {
        // Create two new arrays and make the pointers point to them
        questions = [[NSMutableArray alloc] init];
        
        //Add questions and answers to the array
        [questions addObject:@"It is certain"];
        [questions addObject:@"It is decidedly so"];
        [questions addObject:@"Yes - definitely"];
        [questions addObject:@"You may rely on it"];
        [questions addObject:@"As I see it, yes"];
        [questions addObject:@"Most likely"];
        [questions addObject:@"Outlook good"];
        [questions addObject:@"Yes"];
        [questions addObject:@"Signs point to yes"];
        [questions addObject:@"Reply hazy, try again"];
        [questions addObject:@"Ask again later"];
        [questions addObject:@"Better not tell you now"];
        [questions addObject:@"Cannot predict now"];
        [questions addObject:@"Concentrate and ask again"];
        [questions addObject:@"Don't count on it"];
        [questions addObject:@"My reply is no"];
        [questions addObject:@"My sources say no"];
        [questions addObject:@"Outlook no so good"];
        [questions addObject:@"Very dobtful"];
        
      
         currentQuestionIndex    = -1;
       
    }
    // Return the address of the new object
    return self;
}
- (IBAction)showImage:(id)sender; {
    
    // Step to the random answer
    
    currentQuestionIndex = rand()% [questions count];
 
    // Display it in the answer field
    printf("currentQuestionIndex %i\n",currentQuestionIndex);
    
    [answerField setText:[questions objectAtIndex:currentQuestionIndex]];
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
//    [[self window] makeKeyAndVisible];
    return YES;
}

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

@end
