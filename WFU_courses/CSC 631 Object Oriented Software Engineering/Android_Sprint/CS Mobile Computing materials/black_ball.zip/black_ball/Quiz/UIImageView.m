//
//  UIImageView.m
//  Quiz
//
//  Created by Daniel Canas on 11/9/12.
//
//

#import "UIImageView.h"

@implementation UIImageView

@end
