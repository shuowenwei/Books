package com.example.diabetesapp;
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHandler extends SQLiteOpenHelper{
	//database Version
		public static final String TAG ="Tags";
		
		private static final int DATABASE_VERSION = 1;
		
		//Database Name
		private static final String DATABASE_NAME = "infoByDate";
		
		//DibatestData table name
		private static final String TABLE_DIABETESDATA = "diabetesdata";
		
		//diabetes table column names
		
		private static final String KEY_YEAR = "year";
		private static final String KEY_MONTH = "month";
		private static final String KEY_DAY = "date";
		private static final String KEY_TIME = "time";
		private static final String KEY_MEAL_TIME = "log_before_or_after_meal";
		private static final String KEY_GLUCOSE_LEVEL = "glucose_level";
		private static final String KEY_WORK_TIME = "time_worked";
		private static final String KEY_SLEEP = "amount_of_sleep";
		private static final String KEY_STRESS = "stess_level";
		private static final String KEY_EXERCISE = "exercise_level";
		private static final String KEY_MEAL ="Meal_desciption";
		private static final String KEY_DESCRIPTOR = "Description_of_Log_Entry";
		public DatabaseHandler(Context context){
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
	
		//Creating tables
		@Override
		public void onCreate(SQLiteDatabase db){
			String CREATE_DIABETESDATA_TABLE = "CREATE TABLE " + TABLE_DIABETESDATA + " ( "
					+KEY_YEAR + " VARCHAR(255), " + KEY_MONTH + " VARCHAR(255), "
					+KEY_DAY +" VARCHAR(255), " +KEY_TIME+" VARCHAR(255), "+KEY_GLUCOSE_LEVEL+" VARCHAR(255), " 
					+KEY_MEAL_TIME+" VARCHAR(255), " + KEY_WORK_TIME + " VARCHAR(255), "+ KEY_SLEEP +" VARCHAR(255), "
					+KEY_STRESS+" VARCHAR(255), " + KEY_EXERCISE + " VARCHAR(255), " + KEY_MEAL + " VARCHAR(1000), "
					+ KEY_DESCRIPTOR + " VARCHAR(1000), PRIMARY KEY ( " + KEY_YEAR + ", "+KEY_MONTH + ", " + KEY_DAY + ", " + KEY_TIME +" ))";
			db.execSQL(CREATE_DIABETESDATA_TABLE);
			Log.i(TAG, "Log entrty: Database Created");
		}
	
		//Upgrading database
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_DIABETESDATA);
			onCreate(db);
		}
	
		//add data
		public void addData(DiabetesData diabetesdata){
			Log.i(TAG, "Log entrty: in addData");
			SQLiteDatabase db = this.getWritableDatabase();
			Log.i(TAG, "Log entrty: recieved database");
			
			ContentValues values = new ContentValues();
			values.put(KEY_YEAR, diabetesdata.getYear());
			values.put(KEY_MONTH, diabetesdata.getMonth());
			values.put(KEY_DAY, diabetesdata.getDay());
			values.put(KEY_TIME, diabetesdata.getTime());
			values.put(KEY_MEAL_TIME, diabetesdata.getMealTime());
			values.put(KEY_GLUCOSE_LEVEL, diabetesdata.getGlucose());
			values.put(KEY_WORK_TIME, diabetesdata.getWork());
			values.put(KEY_SLEEP, diabetesdata.getSleep());
			values.put(KEY_STRESS, diabetesdata.getStress());
			values.put(KEY_EXERCISE, diabetesdata.getExercise());
			values.put(KEY_MEAL, diabetesdata.getMeal());
			values.put(KEY_DESCRIPTOR, diabetesdata.getDescriptor());
			Log.i(TAG, "Log entrty: set values");
			db.insert(TABLE_DIABETESDATA, null, values);
			Log.i(TAG, "Log entrty: insert callsed");
			db.close();
		}
		
		public DiabetesData getData(int year, int month, int day, int time){
				SQLiteDatabase db = this.getReadableDatabase();
				Cursor cursor = db.query(TABLE_DIABETESDATA, new String[] {KEY_YEAR, KEY_MONTH, KEY_DAY, KEY_TIME, KEY_GLUCOSE_LEVEL, KEY_MEAL_TIME, KEY_WORK_TIME, KEY_SLEEP, KEY_STRESS, KEY_EXERCISE, KEY_MEAL, KEY_DESCRIPTOR}, 
										 KEY_YEAR +"=?" + " AND " + KEY_MONTH +"=?" + " AND " + KEY_DAY + "=?" + 
										 " AND " + KEY_TIME + "=?", new String[] {String.valueOf(year), String.valueOf(month), 
											String.valueOf(day), String.valueOf(time)}, null, null, null, null); 
				if(cursor != null)
					cursor.moveToFirst();
				
				DiabetesData diabetesdata = new DiabetesData(cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9),cursor.getString(10),cursor.getString(11));
				return diabetesdata;
			}
		
		public List<DiabetesData> getALL()
		{
			List<DiabetesData> dataList = new ArrayList<DiabetesData>();
			
			String selectQuery = "SELECT * FROM " + TABLE_DIABETESDATA;
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(selectQuery, null);
			
			if(cursor.moveToFirst()){
				do{
					DiabetesData data = new DiabetesData(cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9),cursor.getString(10),cursor.getString(11));
					dataList.add(data);
				}while (cursor.moveToNext());
			}
			return dataList;
		}
		
		
		public int getDataCount(){
			String countQuery = "SELECT * FROM " + TABLE_DIABETESDATA;
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(countQuery, null);
			
			return cursor.getCount();
		}
		
	//	public int updateData(int year, int month, int day, int time){}
		
    public void deleteData(DiabetesData data){
    	SQLiteDatabase db = this.getWritableDatabase();
    	db.delete(TABLE_DIABETESDATA, KEY_YEAR +"=?" + " AND " + KEY_MONTH +"=?" + " AND " + KEY_DAY + "=?" + 
				 " AND " + KEY_TIME+ "=?" , new String[]{String.valueOf(data.getYear()), String.valueOf(data.getMonth()), String.valueOf(data.getDay()), String.valueOf(data.getTime())});
    	db.close();
    }
}





