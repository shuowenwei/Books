package com.example.diabetesapp;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ExtraActivity extends Activity {
	
	DatabaseHandler db = new DatabaseHandler(this);
	TextView data_receive;
	
	
	EditText year;
	EditText month;
	EditText day;
	EditText time;
	
	public static final String TAG ="Tags";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_extra);
		
		data_receive = (TextView) findViewById(R.id.Extra_datareceive);
		
		
		// Gets the data repository in read mode
		SQLiteDatabase dbRead = db.getReadableDatabase();				
		String[] projection = {
				DatabaseHandler.KEY_YEAR,
				DatabaseHandler.KEY_MONTH,
				DatabaseHandler.KEY_DAY,
				DatabaseHandler.KEY_TIME
				};

		// The Cursor contains the data resulting from the query
		Cursor c = dbRead.query(
				DatabaseHandler.TABLE_DIABETESDATA,  // The table to query
				projection,                               // The columns to return
				null,                                // The columns for the WHERE clause
				null,                               // The values for the WHERE clause
				null,                                     // don't group the rows
				null,                                     // don't filter by row groups
				null                                 // The sort order
				);
		
		// Iterate through the Cursor to get the data
		// ArrayList<String> list = new ArrayList<String>();
		String year, month, day, time;
		String total = "Year | Month | Day | Time \n";
		c.moveToFirst();
		do {
				year = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_YEAR));
				month = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_MONTH));
				day = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_DAY));
				time = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_TIME));
				total = total + year+" - "+ month+" - "+ day+" - "+ time+ ";\n";
				// list.add(year); 
				}while(c.moveToNext());				
		data_receive.setText("\nData in the database: \n" + total);
		dbRead.close();
	}
	
	public void data_Delete(View v){
		
		//SQLiteDatabase dbDelete = db.getWritableDatabase();
		Log.i(TAG, "problem 0");
		
		year = (EditText)findViewById(R.id.delete_Yeah);
		month = (EditText)findViewById(R.id.delete_Month);
		day = (EditText)findViewById(R.id.delete_Day);
		time = (EditText)findViewById(R.id.delete_Time);
	
		Log.i(TAG, "problem 1");
		
		DiabetesData DataToDelete = new DiabetesData(
				Integer.parseInt(year.getText().toString()),
				Integer.parseInt(month.getText().toString()),
				Integer.parseInt(day.getText().toString()),
				Integer.parseInt(time.getText().toString())
				); 
		
		//DataToDelete.year_ = Integer.parseInt(year.getText().toString());
		//DataToDelete.month_ = Integer.parseInt(month.getText().toString());
		//DataToDelete.day_ = Integer.parseInt(day.getText().toString());
		//DataToDelete.time_ = Integer.parseInt(time.getText().toString());
		
		Log.i(TAG, "problem 2");
		
		db.deleteData(DataToDelete);
		
		Log.i(TAG, "problem 3");
		/*
		String where = 	DatabaseHandler.KEY_YEAR + " = ' " + year.getText().toString() + "' and " + 
				 		DatabaseHandler.KEY_MONTH + " = '" + month.getText().toString() +"' and " +
						DatabaseHandler.KEY_DAY + " = ' " + day.getText().toString() +"' and " +
						DatabaseHandler.KEY_TIME + " = '" + time.getText().toString();
				
		dbDelete.delete(DatabaseHandler.TABLE_DIABETESDATA, where, null);
		
		dbDelete.delete(DatabaseHandler.TABLE_DIABETESDATA, DatabaseHandler.KEY_YEAR +"=?" + " AND " + DatabaseHandler.KEY_MONTH +"=?" + " AND " + DatabaseHandler.KEY_DAY + "=?" + 
				 " AND " + DatabaseHandler.KEY_TIME + "=?" , new String[]{String.valueOf(DataToDelete.getYear()), String.valueOf(DataToDelete.getMonth()), String.valueOf(DataToDelete.getDay()), String.valueOf(DataToDelete.getTime())});
		dbDelete.close();
		*/
		
		Intent intent = new Intent(this, ExtraActivity.class);
		startActivity(intent);
		Log.i(TAG, "problem 4");
	}
	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.extra, menu);
		return true;
	}
	*/
}
