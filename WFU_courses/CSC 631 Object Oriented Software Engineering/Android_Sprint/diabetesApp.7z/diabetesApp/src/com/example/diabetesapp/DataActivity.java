package com.example.diabetesapp;

import android.app.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DataActivity extends Activity {


	DatabaseHandler db = new DatabaseHandler(this);
	DiabetesData data;
	TextView txt;
	//ListView listview;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_data);
		
		// Button testButton = (Button)findViewById(R.id.enterButton);
		
		txt = (TextView) findViewById(R.id.receive);
		
		//listview = (ListView)findViewById(R.id.listView1);
		
		//data = db.getData(2004, 11, 03, 1230);
    	//txt.setText(data.getYear()+", "+data.getMonth()+", "+data.getDay()+", "+data.getTime());
    	
		/*
        testButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
            	
            	data = db.getData(2004, 11, 03, 1230);
            	txt.setText(data.getYear()+", "+data.getMonth()+", "+data.getDay()+", "+data.getTime());
	        }
        });
        */ // wsw
	}
	
	public void enterButton(View v) {
		// Gets the data repository in read mode
		SQLiteDatabase dbRead = db.getReadableDatabase();
		
		//listview = (ListView)findViewById(R.id.listView1);
		// Show rows from the database in the listview
		
		String[] projection = {
				DatabaseHandler.KEY_YEAR,
				DatabaseHandler.KEY_MONTH,
				DatabaseHandler.KEY_DAY,
				DatabaseHandler.KEY_TIME
		};

		// The Cursor contains the data resulting from the query
		Cursor c = dbRead.query(
				DatabaseHandler.TABLE_DIABETESDATA,  // The table to query
				projection,                               // The columns to return
				null,                                // The columns for the WHERE clause
				null,                               // The values for the WHERE clause
				null,                                     // don't group the rows
				null,                                     // don't filter by row groups
				null                                 // The sort order
				);
		
		// Iterate through the Cursor to get the data
		// ArrayList<String> list = new ArrayList<String>();
		String year, month, day, time;
		String total = "Year | Month | Day | Time \n";
		
		c.moveToFirst();
		do {
			year = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_YEAR));
			month = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_MONTH));
			day = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_DAY));
			time = c.getString(c.getColumnIndexOrThrow(DatabaseHandler.KEY_TIME));
			total = total + year+" - "+ month+" - "+ day+" - "+ time+ ";\n";
			// list.add(year); 
		}while(c.moveToNext());
		
		txt.setText("\nData in the database: \n" + total);
		dbRead.close();
		
		/*
		StableArrayAdapter adapter = new StableArrayAdapter(this,
				android.R.layout.simple_list_item_1, list);
		listview.setAdapter(adapter);
		*/
		

	}
	/*
	class StableArrayAdapter extends ArrayAdapter<String> {

		HashMap<String, Integer> mIdMap = new HashMap<String, Integer>();

		public StableArrayAdapter(Context context, int textViewResourceId,
				List<String> objects) {
			super(context, textViewResourceId, objects);
			for (int i = 0; i < objects.size(); ++i) {
				mIdMap.put(objects.get(i), i);
			}
		}

		@Override
		public long getItemId(int position) {
			String item = getItem(position);
			return mIdMap.get(item);
		}
		
		@Override
		public boolean hasStableIds() {
			return true;
		}
	}
	*/
}
