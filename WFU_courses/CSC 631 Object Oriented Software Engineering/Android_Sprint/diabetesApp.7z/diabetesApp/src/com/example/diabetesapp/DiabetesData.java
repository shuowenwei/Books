package com.example.diabetesapp;

public class DiabetesData {
	//private variables
	int year_;
	int month_;
	int day_;
	int time_;
	
	// wsw
	
	// int amout_; 
	
	// wsw
	
	//empty constructor 
	public DiabetesData(){
	}
	
	//constructor
	public DiabetesData(int year, int month, int day, int time){ // int amout){
		this.year_ = year;
		this.month_ = month;
		this.day_ = day;
		this.time_ = time;
		// this.amout_ = amout;
	}
	
	//get year
	public int getYear(){
		return year_;
	}
	
	public int getMonth(){
		return month_;
	}
	
	public int getDay(){
		return day_;
	}
	
	public int getTime(){
		return time_;
	}
	
	// wsw
	/*
	public int getAmount(){
		return amout_;
	}
	*/
	// wsw
}
