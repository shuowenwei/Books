package com.example.diabetesapp;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;

public class MainActivity extends Activity {

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
                
        setContentView(R.layout.activity_main);
        Button goToLog = (Button)findViewById(R.id.logButton);
        Button goToData = (Button)findViewById(R.id.dataButton);
        Button goToPicture = (Button)findViewById(R.id.pictureButton);
        Button goToGraphs = (Button)findViewById(R.id.graphButton);
        Button goToResults = (Button)findViewById(R.id.resultButton);
        Button goToExtra = (Button)findViewById(R.id.extraButton);
        
        
        goToLog.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, LogEntry.class);
	        	startActivity(buttonPushed);
	        	
	        }
        });
        
        goToData.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, DataActivity.class);
	        	startActivity(buttonPushed);
        	}
        });
        
        goToPicture.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, PictureActivity.class);
	        	startActivity(buttonPushed);
            }
         });   
        goToGraphs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, GraphsActivity.class);
	        	startActivity(buttonPushed);
            }
         });     
        
        goToResults.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, ResultsActivity.class);
	        	startActivity(buttonPushed);
            }
         });     
        
        goToExtra.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
	        	Intent buttonPushed = new Intent(MainActivity.this, ExtraActivity.class);
	        	startActivity(buttonPushed);
            }
         });     
    }
}
