package com.example.diabetesapp;


import android.app.Activity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import android.widget.EditText; // wsw 

public class LogEntry extends Activity {
	DatabaseHandler db;
	
	// wsw
	EditText year;
	EditText month;
	EditText day;
	EditText time;
	// wsw
	
	public static final String TAG ="Tags";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "Log entrty: Oncreate");
		setContentView(R.layout.activity_log_entry);
		
        // wsw
		year = (EditText)findViewById(R.id.year);
		month = (EditText)findViewById(R.id.month);
		day = (EditText)findViewById(R.id.day);
		time = (EditText)findViewById(R.id.time);

		// wsw
		
		db = new DatabaseHandler(this);
		
		Log.i(TAG, "Log entrty: Oncreate: after databaseHandler");
		
		//Button testButton = (Button)findViewById(R.id.enterData);
		Log.i(TAG, "Log entrty: BUTON CREATED");
		
		// wsw delete this part below? 
		/*
        testButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
            	db.addData(new DiabetesData(2004, 11, 03, 1230));
	        }
        });
        */
        // wsw
	}

	// wsw
	public void enterData(View v) {
		// Gets the data repository in write mode
		SQLiteDatabase dbInsert = db.getWritableDatabase();
		
		// Get data from edit fields
		int intYear = Integer.parseInt(year.getText().toString());
		int intMonth = Integer.parseInt(month.getText().toString());
		int intDay = Integer.parseInt(day.getText().toString());
		int intTime = Integer.parseInt(time.getText().toString());

		
		// Create a new map of values, where column names are the keys
		ContentValues values = new ContentValues();
		values.put(DatabaseHandler.KEY_YEAR, intYear);
		values.put(DatabaseHandler.KEY_MONTH, intMonth);
		values.put(DatabaseHandler.KEY_DAY, intDay);
		values.put(DatabaseHandler.KEY_TIME, intTime);
		
		
		// Insert the new row, returning the primary key value of the new row
		long newRowId;
		newRowId = dbInsert.insert(
				DatabaseHandler.TABLE_DIABETESDATA,
				"nullable",
				values);
		dbInsert.close();

		// Intent intent = new Intent(this, DataActivity.class);
		// startActivity(intent);
	}

	// wsw 
}
