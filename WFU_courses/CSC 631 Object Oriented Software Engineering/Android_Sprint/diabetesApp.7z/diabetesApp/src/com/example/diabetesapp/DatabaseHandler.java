package com.example.diabetesapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper{
		// wsw
	
	
		//database Version
		public static final int DATABASE_VERSION = 1;
		//private static final int DATABASE_VERSION = 1;
		
		//Database Name
		public static final String DATABASE_NAME = "infoByDate";
		//private static final String DATABASE_NAME = "infoByDate";
		
		//DibatestData table name
		public static final String TABLE_DIABETESDATA = "diabetesdata";
		//private static final String TABLE_DIABETESDATA = "diabetesdata";
		
		//diabetes table column names
		
		
		
		public static final String KEY_YEAR = "year";
		public static final String KEY_MONTH = "month";
		public static final String KEY_DAY = "date";
		public static final String KEY_TIME = "time";
		
		//private static final String KEY_YEAR = "year";
		//private static final String KEY_MONTH = "month";
		//private static final String KEY_DAY = "date";
		//private static final String KEY_TIME = "time";

		//wsw
		
		public DatabaseHandler(Context context){
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
	
		//Creating tables
		@Override
		public void onCreate(SQLiteDatabase db){
			String CREATE_DIABETESDATA_TABLE = "CREATE TABLE " + TABLE_DIABETESDATA + "("
					+KEY_YEAR + " INTEGER(4), " + KEY_MONTH + " INTEGER(2), "
					+KEY_DAY +" INTEGER(2), " +KEY_TIME+" INTEGER(4), PRIMARY KEY (" + KEY_YEAR + ", "+KEY_MONTH + ", " + KEY_DAY + ", " + KEY_TIME +"))";
			db.execSQL(CREATE_DIABETESDATA_TABLE);
		}
	
		//Upgrading database
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_DIABETESDATA);
			onCreate(db);
		}
	
		//add data
		public void addData(DiabetesData diabetesdata){
			SQLiteDatabase db = this.getWritableDatabase();
			
			ContentValues values = new ContentValues();
			values.put(KEY_YEAR, diabetesdata.getYear());
			values.put(KEY_MONTH, diabetesdata.getMonth());
			values.put(KEY_DAY, diabetesdata.getDay());
			values.put(KEY_TIME, diabetesdata.getTime());
			
			db.insert(TABLE_DIABETESDATA, null, values);
			db.close();
		}
		
		public DiabetesData getData(int year, int month, int day, int time){
				SQLiteDatabase db = this.getReadableDatabase();
				Cursor cursor = db.query(TABLE_DIABETESDATA, new String[] {KEY_YEAR, KEY_MONTH, KEY_DAY, KEY_TIME}, 
										 KEY_YEAR +"=?" + " AND " + KEY_MONTH +"=?" + " AND " + KEY_DAY + "=?" + 
										 " AND " + KEY_TIME + "=?", new String[] {String.valueOf(year), String.valueOf(month), 
											String.valueOf(day), String.valueOf(time)}, null, null, null, null); 
				if(cursor != null)
					cursor.moveToFirst(); // what does this do?
				
				DiabetesData diabetesdata = new DiabetesData(Integer.parseInt(cursor.getString(0)),Integer.parseInt(cursor.getString(1)),
						                                     Integer.parseInt(cursor.getString(2)), Integer.parseInt(cursor.getString(3)));
				return diabetesdata;
			}
		
		public int getDataCount(){
			String countQuery = "SELECT * FROM " + TABLE_DIABETESDATA;
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(countQuery, null);	
			return cursor.getCount();
		}

	//	public int updateData(int year, int month, int day, int time){}
		
    public void deleteData(DiabetesData data){
    	SQLiteDatabase db = this.getWritableDatabase();
    	db.delete(TABLE_DIABETESDATA, KEY_YEAR +"=?" + " AND " + KEY_MONTH +"=?" + " AND " + KEY_DAY + "=?" + " AND " + KEY_TIME + "=?",
    			new String[]{String.valueOf(data.getYear()), String.valueOf(data.getMonth()), String.valueOf(data.getDay()), String.valueOf(data.getTime())});
    	db.close();
    }
}





