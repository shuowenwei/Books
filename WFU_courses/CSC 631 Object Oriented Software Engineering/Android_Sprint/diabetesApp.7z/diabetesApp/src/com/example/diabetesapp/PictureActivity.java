package com.example.diabetesapp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

public class PictureActivity extends Activity implements SurfaceHolder.Callback {
	private Camera camera;
	
	Button  btnClosePopup;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_picture);
		
	    SurfaceView surface = (SurfaceView)findViewById(R.id.surfaceView1);
	    SurfaceHolder holder = surface.getHolder();
	    holder.addCallback(this);
	   // holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	   Button snap = (Button)findViewById(R.id.buttonTakePicture);

	   
	    snap.setOnClickListener(new OnClickListener() {
	        public void onClick(View v) {
	          takePicture(); 
	        }
	      });
		
	}
	
	
	  public void surfaceCreated(SurfaceHolder holder) { 
		    try {
		      camera.setPreviewDisplay(holder);
		      camera.startPreview();
		      camera.setDisplayOrientation(90);
		  
	    } catch (IOException e) {
	        
	      }
	  }
	  
	  public void surfaceDestroyed(SurfaceHolder holder) {
		    camera.stopPreview();
		  }
	  
	  public void surfaceChanged(SurfaceHolder holder, int format, 
              int width, int height) {
		  
}
	  
	  @Override
	  protected void onPause() {
	    super.onPause();
	    camera.release();
	  }

	  @Override
	  protected void onResume() {
	    super.onResume();
	    camera = Camera.open();        
	  }
	  
	  private void takePicture() {
		    camera.takePicture(shutterCallback, rawCallback, jpegCallback);
		    initiatePopupWindow();
		    
		  }

		  ShutterCallback shutterCallback = new ShutterCallback() {
		    public void onShutter() {
		      // TODO Do something when the shutter closes.
		    }
		  };

		  PictureCallback rawCallback = new PictureCallback() {
		    public void onPictureTaken(byte[] data, Camera camera) {
		      // TODO Do something with the image RAW data.
		    }
		  };

		  PictureCallback jpegCallback = new PictureCallback() {
		    public void onPictureTaken(byte[] data, Camera camera) {
		      // Save the image JPEG data to the SD card
		      FileOutputStream outStream = null;
		      try {
		        String path = Environment.getExternalStorageDirectory() + 
		                      "\test.jpg";

		        outStream = new FileOutputStream(path);
		        outStream.write(data);
		        outStream.close();
		      } catch (FileNotFoundException e) {
		        //Log.e(TAG, "File Note Found", e);
		      } catch (IOException e) {
		       // Log.e(TAG, "IO Exception", e);
		      }
		    }
		  };
		  
		  private PopupWindow pwindo;

		  private void initiatePopupWindow() { 
		  try { 
			  // We need to get the instance of the LayoutInflater 
			  LayoutInflater inflater = (LayoutInflater) PictureActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
			  View layout = inflater.inflate(R.layout.camera_popup,(ViewGroup)findViewById(R.id.popup_element)); 
			  pwindo = new PopupWindow(layout, 350, 350, true); 
			  pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);
	
			  btnClosePopup = (Button) layout.findViewById(R.id.btn_close_popup); 
			  btnClosePopup.setOnClickListener(cancel_button_click_listener);

		  } catch (Exception e) { 
		  e.printStackTrace(); 
		  } 
		  }

		  private OnClickListener cancel_button_click_listener = new OnClickListener() { 
		  public void onClick(View v) { 
		  pwindo.dismiss();
		  camera.startPreview();

		  } 
		  };
		  
	}
	




