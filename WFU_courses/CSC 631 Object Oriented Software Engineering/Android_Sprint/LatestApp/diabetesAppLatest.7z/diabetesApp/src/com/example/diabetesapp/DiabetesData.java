package com.example.diabetesapp;

import java.io.Serializable;

public class DiabetesData implements Serializable{
	//private variables
	String year_;
	String month_;
	String day_;
	String time_;
	String mealTime_;
	String glucose_;
	String work_;
	String sleep_;
	String stress_;
	String exercise_;
	String meal_;
	String descriptor_;
	
	//empty constructor 
	public DiabetesData(){
	}
	
	//constructor
	public DiabetesData(String year, String month, String day, String time, String mealTime, String glucose, String work, String sleep, String stress, String exercise, String meal, String descriptor){
		this.year_ = year;
		this.month_ = month;
		this.day_ = day;
		this.time_ = time;
		this.mealTime_ = mealTime;
		this.glucose_ = glucose;
		this.work_ = work;
		this.sleep_ = sleep;
		this.stress_ = stress;
		this.exercise_ = exercise;
		this.meal_ = meal;
		this.descriptor_ = descriptor;
	}
	
	
	//get year
	public String getYear(){
		return year_;
	}
	
	public String getMonth(){
		return month_;
	}
	
	public String getDay(){
		return day_;
	}
	
	public String getTime(){
		return time_;
	}
	
	public String getMealTime(){
		return mealTime_;
	}
	
	public String getGlucose(){
		return glucose_;
	}
	
	public String getWork(){
		return work_;
	}
	
	public String getSleep(){
		return sleep_;
	}
	
	public String getStress(){
		return stress_;
	}
	
	public String getExercise(){
		return exercise_;
	}
	
	public String getMeal(){
		return meal_;
	}
	
	public String getDescriptor(){
		return descriptor_;
	}

}
