package com.example.diabetesapp;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;

public class DataActivity extends Activity {

	DatabaseHandler db = new DatabaseHandler(this);
	DiabetesData data = null;
	TextView header;
	Spinner entries;
	Button deleteButton;
	Button readButton;
	ArrayAdapter<CharSequence> spinAdapter;
	List<DiabetesData> dataList = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_data);
		
		header = (TextView)findViewById(R.id.activityHeader);
		deleteButton = (Button)findViewById(R.id.delete);
		readButton = (Button)findViewById(R.id.open);
		entries = (Spinner)findViewById(R.id.entries);
		
		spinAdapter = new ArrayAdapter<CharSequence> (this, android.R.layout.simple_spinner_item);
		spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		
		dataList = db.getALL();
		
		for(int i = 0; i < dataList.size(); i++)
		{
			spinAdapter.add(dataList.get(i).getMonth() + " - "+dataList.get(i).getDay() + " - " + dataList.get(i).getYear() + " at " + dataList.get(i).getTime());
		}
		entries.setAdapter(spinAdapter);
		
		

		entries.setOnItemSelectedListener(new OnItemSelectedListener(){
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				data = dataList.get(position);
			}
			
			public void onNothingSelected(AdapterView<?> parent){
				data = null;
			}
		});
		
		 readButton.setOnClickListener(new View.OnClickListener() {
	            public void onClick(View arg0){
	            	if (data != null)
	            	{
			        	Intent readPushed = new Intent(DataActivity.this, DisplayLog.class);
			        	readPushed.putExtra("Data", data);
			        	startActivity(readPushed);
	            	}	
		        }
	        });
		deleteButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (data != null)
				{
					db.deleteData(data);
					Intent intent = getIntent();
	            	finish();
	            	startActivity(intent);  
				}
				
			}
		});
	}
}
