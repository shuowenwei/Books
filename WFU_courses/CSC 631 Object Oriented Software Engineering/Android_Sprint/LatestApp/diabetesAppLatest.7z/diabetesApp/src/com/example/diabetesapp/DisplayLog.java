package com.example.diabetesapp;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;

public class DisplayLog extends Activity {

	TextView date;
	TextView glucose;
	TextView mealTime;
	TextView work;
	TextView exercise;
	TextView stress;
	TextView sleep;
	TextView meal;
	TextView descriptor;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display_log);
		
		Intent getData = getIntent();
		DiabetesData data = (DiabetesData)getData.getSerializableExtra("Data");
		
		date = (TextView)findViewById(R.id.dateDisplay);
		glucose = (TextView)findViewById(R.id.Blood_Glucose1);
		mealTime = (TextView)findViewById(R.id.mealBoxText1);
		work = (TextView)findViewById(R.id.workText1);
		exercise = (TextView)findViewById(R.id.exerciseText1);
		stress = (TextView)findViewById(R.id.stressText1);
		sleep = (TextView)findViewById(R.id.sleepText1);
		meal = (TextView)findViewById(R.id.Describe_meal1);
		descriptor = (TextView)findViewById(R.id.Descript_All1);
		
		date.append(data.getMonth()+" "+data.getDay()+", "+data.getYear()+" "+data.getTime());
		glucose.append(data.getGlucose()+" mg/dl.");
		mealTime.append(data.getMealTime()+".");
		work.append(data.getWork()+" horus.");
		exercise.append(data.getExercise()+" horus.");
		stress.append(data.getStress()+".");
		sleep.append(data.getSleep()+" horus.");
		meal.append(data.getMeal());
		descriptor.append(data.getDescriptor());
		
	}

}
