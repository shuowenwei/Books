package com.example.diabetesapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class LogEntry extends Activity {
	Calendar grabDate = Calendar.getInstance();
	SimpleDateFormat dayGrab = new SimpleDateFormat("dd");
	SimpleDateFormat monthGrab = new SimpleDateFormat("MM");
	SimpleDateFormat yearGrab = new SimpleDateFormat("yyyy");
	SimpleDateFormat timeGrab = new SimpleDateFormat("HH:mm");
	String day = dayGrab.format(grabDate.getTime());
	String month = monthGrab.format(grabDate.getTime());
	String year = yearGrab.format(grabDate.getTime());
	String time = timeGrab.format(grabDate.getTime());
	String mealTimeS = " ";
	String glucoseS = " ";
	String workS = " ";
	String sleepS = " ";
	String stressS = " ";
	String exerciseS = " ";
	String mealS = " ";
	String descriptorS= " ";
	
	Button sButton;
	RadioButton mealGroupB, mealGroupA;
	Spinner workSpin;
	Spinner exerciseSpin;
	Spinner sleepSpin;
	Spinner stressSpin;
	EditText glucoseEdit;
	EditText mealEdit;
	EditText descriptorEdit;
	
	DatabaseHandler db;
	public static final String TAG ="Tags";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "Log entrty: Oncreate");
		setContentView(R.layout.activity_log_entry);
		TextView t = (TextView)findViewById(R.id.dateDisplay);
		t.append(time+" "+month+" "+day+", "+year);
		
		//insure the database has been created
		db = new DatabaseHandler(this);
		
		//Log.i(TAG, "Log entry: Oncreate: after databaseHandler");
		
		//associate all needed objects with xml 
		sButton = (Button)findViewById(R.id.submit);
		mealGroupB = (RadioButton)findViewById(R.id.before);
		mealGroupA = (RadioButton)findViewById(R.id.after);
		workSpin = (Spinner)findViewById(R.id.work);
		exerciseSpin = (Spinner)findViewById(R.id.exercise);
		sleepSpin = (Spinner)findViewById(R.id.sleep);
		stressSpin = (Spinner)findViewById(R.id.stress);
		glucoseEdit = (EditText)findViewById(R.id.blood_G);
		mealEdit = (EditText)findViewById(R.id.Describe_meal);
		descriptorEdit = (EditText)findViewById(R.id.Descript_All);
		
		//Spinners
		ArrayAdapter<CharSequence> workAdapter = ArrayAdapter.createFromResource(this,
				R.array.work_amount, android.R.layout.simple_spinner_dropdown_item);
		ArrayAdapter<CharSequence> exerciseAdapter = ArrayAdapter.createFromResource(this, 
				R.array.work_amount, android.R.layout.simple_spinner_dropdown_item);
		ArrayAdapter<CharSequence> sleepAdapter = ArrayAdapter.createFromResource(this, 
				R.array.sleep_amount, android.R.layout.simple_spinner_dropdown_item);
		ArrayAdapter<CharSequence> stressAdapter = ArrayAdapter.createFromResource(this, 
				R.array.stress_levels, android.R.layout.simple_spinner_dropdown_item);
		workAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		exerciseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sleepAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		stressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		workSpin.setAdapter(workAdapter);
		exerciseSpin.setAdapter(exerciseAdapter);
		sleepSpin.setAdapter(sleepAdapter);
		stressSpin.setAdapter(stressAdapter);
	
		workSpin.setOnItemSelectedListener(new OnItemSelectedListener(){
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				workS = parent.getItemAtPosition(position).toString();
			}
			
			public void onNothingSelected(AdapterView<?> parent){
				workS = " ";
			}
		});
		
		exerciseSpin.setOnItemSelectedListener(new OnItemSelectedListener(){
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				exerciseS = parent.getItemAtPosition(position).toString();
			}
			
			public void onNothingSelected(AdapterView<?> parent){
				exerciseS = " ";
			}
		});
		
		sleepSpin.setOnItemSelectedListener(new OnItemSelectedListener(){
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				sleepS = parent.getItemAtPosition(position).toString();
			}
			
			public void onNothingSelected(AdapterView<?> parent){
				sleepS = " ";
			}
		});
		
		stressSpin.setOnItemSelectedListener(new OnItemSelectedListener(){
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				stressS = parent.getItemAtPosition(position).toString();
			}
			
			public void onNothingSelected(AdapterView<?> parent){
				stressS = " ";
			}
		});
		
		
		//Radio Buttons
		mealGroupB.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				mealGroupA.setChecked(false);
				mealGroupB.setChecked(true);
				mealTimeS = "Before";
			}
		});
		mealGroupA.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				mealGroupA.setChecked(true);
				mealGroupB.setChecked(false);
				mealTimeS = "After";
			}
		});
		
		
        sButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){
            	glucoseS = glucoseEdit.getText().toString();
            	mealS = mealEdit.getText().toString();
            	descriptorS = descriptorEdit.getText().toString();
        		day = dayGrab.format(grabDate.getTime());
        		month = monthGrab.format(grabDate.getTime());
        		year = yearGrab.format(grabDate.getTime());
        		time = timeGrab.format(grabDate.getTime());
        		
        		Log.i(TAG, "Log entry: About to add entry");
        		
            	db.addData(new DiabetesData(year, month, day, time, mealTimeS, glucoseS, workS, sleepS, stressS, exerciseS, mealS, descriptorS));
            	Log.i(TAG, "Log entry: Entry added");
        		
            	Intent intent = getIntent();
            	finish();
            	startActivity(intent);  
	        }    
        });
	}
}
	

