package com.example.diabetesapp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;

public class PictureActivity extends Activity implements SurfaceHolder.Callback {
	
	public static final String TAG ="Tags";
	private Camera camera;
	private PopupWindow pwindo;
	private Button  btnClosePopup;
	private Button  btnKeepPhoto;
	byte[] data;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_picture);
		
	    SurfaceView surface = (SurfaceView)findViewById(R.id.surfaceView1);
	    SurfaceHolder holder = surface.getHolder();
	    holder.addCallback(this);
	   Button snap = (Button)findViewById(R.id.buttonTakePicture);

	   
	    snap.setOnClickListener(new OnClickListener() {
	        public void onClick(View v) {
	          takePicture(); 
	        }
	      });
		
	}
	
	
	  public void surfaceCreated(SurfaceHolder holder) { 
		    try {
		      camera.setPreviewDisplay(holder);
		      camera.startPreview();
		      camera.setDisplayOrientation(90);
		  
		    } catch (IOException e) {}
	  }
	  
	  public void surfaceDestroyed(SurfaceHolder holder) {
		    camera.stopPreview();
	  }
	  
	  public void surfaceChanged(SurfaceHolder holder, int format, 
              int width, int height) {
	  }
	  
	  @Override
	  protected void onPause() {
		  camera.release();
	    super.onPause();
	    
	  }

	  @Override
	  protected void onResume() {
	    super.onResume();
	    camera = Camera.open();        
	  }
	  
	  private void takePicture() {
		  	
		    camera.takePicture(shutterCallback, rawCallback, jpegCallback); 
		    initiatePopupWindow();
	  }
	  
	  public void onBackPressed(){
		  //Your code here
		   camera.release();
		    camera.stopPreview();
		  super.onBackPressed();
		}

	  ShutterCallback shutterCallback = new ShutterCallback() {
	    public void onShutter() {
	      // TODO Do something when the shutter closes.
	    }
	  };

	  PictureCallback rawCallback = new PictureCallback() {
	    public void onPictureTaken(byte[] data, Camera camera) {
	      // TODO Do something with the image RAW data.
	    }
	  };

	  PictureCallback jpegCallback = new PictureCallback() {
	    public void onPictureTaken(byte[] receiveData, Camera camera) {    	
	    	data = receiveData;
	    }
	  };
	  
		 

	  private void initiatePopupWindow() { 
	  try { 
		  // We need to get the instance of the LayoutInflater 
		  LayoutInflater inflater = (LayoutInflater) PictureActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		  View layout = inflater.inflate(R.layout.camera_popup,(ViewGroup)findViewById(R.id.popup_element)); 
		  pwindo = new PopupWindow(layout, 350, 350, true); 
		  pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);

		  btnClosePopup = (Button) layout.findViewById(R.id.btn_close_popup); 
		  btnClosePopup.setOnClickListener(cancel_button_click_listener);
		  
		  btnKeepPhoto = (Button)layout.findViewById(R.id.keepPicture);
		  btnKeepPhoto.setOnClickListener(keep_button_click_listener);		  

	  } catch (Exception e) { 
		  e.printStackTrace(); 
	  } 
	  }

	  private OnClickListener cancel_button_click_listener = new OnClickListener() { 
		  public void onClick(View v) { 
			  pwindo.dismiss();
			  camera.startPreview(); 

	    	    
		  } 
	  };
	  
	  private OnClickListener keep_button_click_listener = new OnClickListener(){
		public void onClick(View v){
			
		     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
    	     String currentDate = sdf.format(new Date());
    	     ContextWrapper cw = new ContextWrapper(getApplicationContext());
    	     File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
    	     File path = new File(directory,"test.jpg");
    	     Bitmap picture = BitmapFactory.decodeByteArray(data,0, data.length);
    	     
    	     Matrix matrix = new Matrix();
    	     matrix.postRotate(90);
    	     picture = Bitmap.createBitmap(picture, 0, 0, picture.getWidth(), picture.getHeight(), matrix, true);
    	     FileOutputStream fos = null;
    	     try{
    	    	 	fos = new FileOutputStream(path);
    	    	 	picture.compress(Bitmap.CompressFormat.JPEG, 100, fos);
    	    	 
    	     } catch (Exception e){}
    	     Log.i(TAG, directory.getAbsolutePath());
    	     picture.recycle();
    	     pwindo.dismiss();
    	     camera.startPreview();  
		}
	  };
		  
}
	




