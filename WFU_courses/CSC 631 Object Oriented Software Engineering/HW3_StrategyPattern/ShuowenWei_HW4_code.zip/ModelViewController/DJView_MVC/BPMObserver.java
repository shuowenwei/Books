public interface BPMObserver {
	void updateBPM();
}
