THANK YOU FOR DOWNLOADING THE SOURCE CODE FOR CONNECTING TO A MYSQL DATABASE FROM THE TIMKIPPTUTORIALS.COM CODE BANK.

The "tutorial_test_code.php" is for testing your script out before you actually implement it into your site. (not recommended for live use)

The "tutorial_live_code.php" is for live use once you get all your connection information ready.

IF YOU HAVE QUESTIONS, FEEL FREE TO CONTACT ME IN THE FORUMS AT http://www.timkipptutorials.com/forums

THANK YOU AGAIN.

http://www.timkipptutorials.com