	</div>
	
	<div id="template_footer">
	&copy; 2011 PHP Green Site Template With jQuery | <a href="http://www.timkipptutorials.com" target="_blank">TimKippTutorials.com</a>
	</div>

</div>

</body>
</html>