﻿Imports System.IO

Public Class Form1

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
       
    End Sub
End Class
