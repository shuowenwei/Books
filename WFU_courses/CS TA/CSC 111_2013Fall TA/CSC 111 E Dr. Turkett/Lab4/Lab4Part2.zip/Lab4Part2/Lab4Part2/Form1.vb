﻿Public Class Form1

    Private Sub btnCalculateSales_Click(sender As Object, e As EventArgs) Handles btnCalculateSales.Click

    End Sub
End Class
