﻿Imports System.IO
Public Class Form1

    Private Sub btnAnalyze_Click(sender As Object, e As EventArgs) Handles btnAnalyze.Click

    End Sub
End Class
