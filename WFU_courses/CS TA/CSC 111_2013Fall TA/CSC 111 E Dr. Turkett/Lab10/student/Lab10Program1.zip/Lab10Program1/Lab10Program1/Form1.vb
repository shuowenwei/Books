﻿Imports System.IO
Class Form1

    Private Sub btnAnalyze_Click(sender As Object, e As EventArgs) Handles btnAnalyze.Click
        Dim srInput As StreamReader
        Dim NumberofTeams As Integer

        srInput = File.OpenText("teamsales.txt")
        NumberofTeams = srInput.ReadLine()

        Dim TeamName(NumberofTeams - 1) As String
        Dim TeamSales(NumberofTeams - 1) As Double
        Dim intAddress As Integer
        Dim intCount As Integer = 0
        Dim Name As String = ""

        For intAddress = 0 To NumberofTeams - 1
            TeamName(intAddress) = srInput.ReadLine()
            TeamSales(intAddress) = srInput.ReadLine()
        Next

        srInput.Close()

        intCount = TeamSales(0)
        For intAddress = 0 To NumberofTeams - 1
            If TeamSales(intAddress) < intCount Then
                intCount = TeamSales(intAddress)
                Name = TeamName(intAddress)
            End If
        Next
        
        lblNameOutput.Text = Name
        lblSalesOutput.Text = CStr(intCount)


    End Sub

End Class
