﻿Imports System.IO
Public Class Form1

    Private Sub btnAnalyze_Click(sender As Object, e As EventArgs) Handles btnAnalyze.Click
        Dim srInput As StreamReader

        srInput = File.OpenText("customerdata.txt")

        Dim CustData(4, 7) As Double
        Dim intAddress As Integer
        Dim intCount As Integer

        For intAddress = 0 To 4
            For intCount = 0 To 7
                CustData(intAddress, intCount) = srInput.ReadLine()
            Next
        Next

        srInput.Close()

        Dim totalCust As Integer = 0
        Dim CustofDay As Integer

        For intAddress = 0 To 4
            For intCount = 0 To 7
                CustofDay = CustData(intAddress, intCount)
                totalCust = totalCust + CustofDay
            Next
        Next

        lblTotalOutput.Text = CStr(totalCust)

        Dim maxValue As Integer = -1
        Dim maxAddress As Integer = -1

        For intAddress = 0 To 4
            totalCust = 0
            For intCount = 0 To 7
                totalCust += CustData(intAddress, intCount)
            Next
            If totalCust > maxValue Then
                maxValue = totalCust
                maxAddress = intAddress
            End If
        Next

        lblDayOutput.Text = CStr(maxAddress)

    End Sub
End Class
