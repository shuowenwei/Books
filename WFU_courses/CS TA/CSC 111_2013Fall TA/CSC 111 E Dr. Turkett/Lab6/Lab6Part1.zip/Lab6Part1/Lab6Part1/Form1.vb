﻿Public Class Form1

    Private Sub btnAnnual_Click(sender As Object, e As EventArgs) Handles btnAnnual.Click
        'Declare variables
        Dim dblBalance As Double
        Dim dblInterestRate As Double
        Dim dblEndBalance As Double

        ' Get data from GUI as input
        dblBalance = CDbl(txtBalance.Text)
        dblInterestRate = CDbl(txtInterestRate.Text)

        ' Do computations
        ' FINISH THIS AS PART OF LAB, DOES NOT REQUIRE A LOOP!

        ' Display output
        lblBalanceOutput.Text = CStr(dblEndBalance)
    End Sub

    Private Sub btnMonthly_Click(sender As Object, e As EventArgs) Handles btnMonthly.Click
        'Declare variables
        Dim dblBalance As Double
        Dim dblInterestRate As Double
        Dim dblEndBalance As Double
        Dim intCount As Integer

        ' Get data from GUI as input
        dblBalance = CDbl(txtBalance.Text)
        dblInterestRate = CDbl(txtInterestRate.Text)

        ' Do computations
        ' FINISH THIS AS PART OF LAB, DOES REQUIRE A LOOP!

        ' Display output
        lblBalanceOutput.Text = CStr(dblEndBalance)
    End Sub

    Private Sub btnDaily_Click(sender As Object, e As EventArgs) Handles btnDaily.Click
        'Declare variables
        Dim dblBalance As Double
        Dim dblInterestRate As Double
        Dim dblEndBalance As Double
        Dim intCount As Integer

        ' Get data from GUI as input
        dblBalance = CDbl(txtBalance.Text)
        dblInterestRate = CDbl(txtInterestRate.Text)

        ' Do computations
        ' FINISH THIS AS PART OF LAB, DOES REQUIRE A LOOP, USE A DIFFERENT KIND THAN YOU USED ABOVE

        ' Display output
        lblBalanceOutput.Text = CStr(dblEndBalance)
    End Sub
End Class
