﻿Public Class StockSale
    
End Class
