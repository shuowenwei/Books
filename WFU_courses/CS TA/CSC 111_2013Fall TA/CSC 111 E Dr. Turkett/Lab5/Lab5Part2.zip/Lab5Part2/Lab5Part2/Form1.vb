﻿Public Class Form1

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        ' Declare variables needed
        Dim dblPurchasePrice As Double
        Dim dblSellPrice As Double
        Dim dblGain As Double
        Dim dblIncome As Double
        Dim dblTaxToPay As Double  ' Store your final tax value here so it is displayed to the screen

        ' Get input from GUI
        dblPurchasePrice = CDbl(txtPurchasePrice.Text)
        dblSellPrice = CDbl(txtSellPrice.Text)
        dblIncome = CDbl(txtIncome.Text)

        ' Complete instructions here


        ' Print output to GUI
        lblTaxOutput.Text = CStr(dblTaxToPay)
    End Sub
End Class
