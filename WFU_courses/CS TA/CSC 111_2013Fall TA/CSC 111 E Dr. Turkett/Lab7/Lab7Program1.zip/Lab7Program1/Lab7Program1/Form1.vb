﻿Public Class Form1

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        ' Declare variables as needed
        Dim dblInterestRate As Double
        Dim dblBalance As Double
        Dim dblOutputBalance As Double
        Dim intCounter As Integer

        ' Grab interest rate data from GUI
        dblInterestRate = CDbl(txtInterestInput.Text)

        ' Compute the three output balances and print to the GUI
        dblBalance = CDbl(txtBalanceInput.Text) ' in each segment, retrieve the original balance from GUI
        dblOutputBalance = dblBalance * (1 + dblInterestRate) ' do the math
        lblAnnualOutput.Text = CDbl(dblOutputBalance) ' update GUI

        dblBalance = CDbl(txtBalanceInput.Text)
        For intCounter = 1 To 12 Step 1
            dblBalance = dblBalance * (1 + (dblInterestRate / 12))
        Next
        dblOutputBalance = dblBalance
        lblMonthlyOutput.Text = CDbl(dblOutputBalance)

        dblBalance = CDbl(txtBalanceInput.Text)
        For intCounter = 1 To 365 Step 1
            dblBalance = dblBalance * (1 + (dblInterestRate / 365))
        Next
        dblOutputBalance = dblBalance
        lblDailyOutput.Text = CDbl(dblOutputBalance)
    End Sub
End Class
